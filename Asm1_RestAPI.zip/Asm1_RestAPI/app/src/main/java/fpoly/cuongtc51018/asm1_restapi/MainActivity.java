package fpoly.cuongtc51018.asm1_restapi;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    ListView lvMain;
    List<CarModel> listCarModel;
    CarAdapter carAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Thiết lập padding cho hệ thống thanh trạng thái và điều hướng
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        lvMain = findViewById(R.id.listviewMain);

        // Cấu hình Retrofit để gọi API
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(APIService.DOMAIN)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        APIService apiService = retrofit.create(APIService.class);

        // Gọi API để lấy danh sách xe
        fetchCarList(apiService);

        // Xử lý sự kiện nhấn nút btn_add để hiển thị dialog thêm xe
        findViewById(R.id.btn_add).setOnClickListener(v -> showAddCarDialog(apiService));
    }

    // Hàm để lấy danh sách xe
    private void fetchCarList(APIService apiService) {
        Call<List<CarModel>> call = apiService.getCars();
        call.enqueue(new Callback<List<CarModel>>() {
            @Override
            public void onResponse(Call<List<CarModel>> call, Response<List<CarModel>> response) {
                if (response.isSuccessful()) {
                    listCarModel = response.body();
                    carAdapter = new CarAdapter(getApplicationContext(), listCarModel);
                    lvMain.setAdapter(carAdapter);
                } else {
                    Toast.makeText(MainActivity.this, "Failed to load data", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<CarModel>> call, Throwable t) {
                Log.e("Main", t.getMessage());
            }
        });
    }

    // Hàm hiển thị dialog thêm xe
    private void showAddCarDialog(APIService apiService) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_addcar, null);
        builder.setView(dialogView);

        // Khai báo các view trong dialog
        EditText etTen = dialogView.findViewById(R.id.etTen);
        EditText etNam = dialogView.findViewById(R.id.etNam);
        EditText etHang = dialogView.findViewById(R.id.etHang);
        EditText etGia = dialogView.findViewById(R.id.etGia);
        Button btnAddCar = dialogView.findViewById(R.id.btnAddCar);

        AlertDialog dialog = builder.create();
        dialog.show();

        // Xử lý khi nhấn nút Thêm trong dialog
        btnAddCar.setOnClickListener(v -> {
            String carTen = etTen.getText().toString();
            String carNam = etNam.getText().toString();
            String carHang = etHang.getText().toString();
            String carGia = etGia.getText().toString();

            if (carTen.isEmpty() || carNam.isEmpty() || carHang.isEmpty() || carGia.isEmpty()) {
                Toast.makeText(MainActivity.this, "Vui lòng điền đầy đủ thông tin", Toast.LENGTH_SHORT).show();
            } else {
                try {
                    // Tạo đối tượng CarModel từ thông tin nhập vào
                    CarModel xe = new CarModel(null, carTen, Integer.parseInt(carNam), carHang, Double.parseDouble(carGia));

                    // Gửi yêu cầu thêm xe đến API
                    Call<List<CarModel>> callAddCar = apiService.addCar(xe);
                    callAddCar.enqueue(new Callback<List<CarModel>>() {
                        @Override
                        public void onResponse(Call<List<CarModel>> call, Response<List<CarModel>> response) {
                            if (response.isSuccessful() && response.body() != null) {
                                listCarModel.clear();
                                listCarModel.addAll(response.body());
                                carAdapter.notifyDataSetChanged();
                                dialog.dismiss();
                                Toast.makeText(MainActivity.this, "Thêm xe thành công", Toast.LENGTH_SHORT).show();
                            } else {
                                Log.e("Main", "Error adding car: " + response.code() + " - " + response.errorBody());
                                Toast.makeText(MainActivity.this, "Lỗi khi thêm xe: " + response.message(), Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<List<CarModel>> call, Throwable t) {
                            Log.e("Main", "Failure: " + t.getMessage());
                            Toast.makeText(MainActivity.this, "Lỗi kết nối khi thêm xe", Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, "Thông tin không hợp lệ", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
